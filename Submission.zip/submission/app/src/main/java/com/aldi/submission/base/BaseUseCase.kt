package com.aldi.submission.base

open class BaseUseCase {

    private val _keyApp = "83fcacf8806e4051a3431cc66317b110"
    val keyApp = _keyApp
}